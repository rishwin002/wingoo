'use client'

import { RefreshCw, Home, Calendar, Heart, Wallet, User, ChevronRight, Shield, Gift, Info } from 'lucide-react'
import Link from 'next/link'
import Image from 'next/image'

export default function AccountPage() {
  const menuItems = [
    { icon: Shield, label: 'Administrator Area' },
    { icon: Shield, label: 'Security and Safety' },
    { icon: Gift, label: 'Redeem Code' },
    { icon: Info, label: 'About Us' },
  ]

  return (
    <div className="min-h-screen bg-red-600 flex flex-col">
      {/* Header */}
      <div className="p-4 flex justify-between items-center">
        <h1 className="text-xl font-bold text-white">Mine</h1>
        <button className="text-white">
          <RefreshCw className="w-6 h-6" />
        </button>
      </div>

      {/* Profile Section */}
      <div className="px-4 pb-6 text-white">
        <div className="flex items-center gap-4 mb-2">
          <Image
            src="/placeholder.svg?height=64&width=64"
            alt="Profile"
            width={64}
            height={64}
            className="rounded-full"
          />
          <div className="flex-1">
            <h2 className="text-xl font-bold mb-1">DIGIRG CLOUD</h2>
            <div className="flex justify-between items-center">
              <div>
                <div>ID:53621</div>
                <div>Mobile Number:9453642431</div>
              </div>
              <ChevronRight className="w-5 h-5" />
            </div>
          </div>
        </div>
      </div>

      {/* Main Content */}
      <div className="flex-1 bg-white rounded-t-3xl p-4">
        {/* Balance Card */}
        <div className="bg-white rounded-lg p-4 shadow-sm mb-4">
          <div className="flex items-center gap-2 mb-2">
            <Image
              src="/placeholder.svg?height=24&width=24"
              alt="Wallet"
              width={24}
              height={24}
              className="text-pink-500"
            />
            <span>Balance</span>
          </div>
          <div className="text-2xl font-bold mb-4">₹ 51237400</div>
          <div className="grid grid-cols-2 gap-4">
            <button className="py-2 px-4 bg-yellow-400 rounded-full font-medium text-white">
              Withdraw
            </button>
            <button className="py-2 px-4 bg-red-500 rounded-full font-medium text-white">
              Recharge
            </button>
          </div>
        </div>

        {/* Promotion Banner */}
        <Link
          href="/promotion"
          className="block bg-red-500 text-white rounded-lg p-4 mb-4"
        >
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="w-8 h-8 bg-white/20 rounded-full flex items-center justify-center">
                🎯
              </div>
              <span className="text-lg">Promotion</span>
            </div>
            <ChevronRight className="w-5 h-5" />
          </div>
        </Link>

        {/* Menu Items */}
        <div className="space-y-2">
          {menuItems.map((item, index) => {
            const Icon = item.icon
            return (
              <Link
                key={index}
                href={`/${item.label.toLowerCase().replace(/\s+/g, '-')}`}
                className="flex items-center justify-between p-4 border-b"
              >
                <div className="flex items-center gap-3">
                  <Icon className="w-5 h-5 text-red-500" />
                  <span>{item.label}</span>
                </div>
                <ChevronRight className="w-5 h-5 text-gray-400" />
              </Link>
            )
          })}
        </div>
      </div>

      {/* Bottom Navigation */}
      <div className="fixed bottom-0 left-0 right-0 h-16 bg-white border-t flex items-center justify-around">
        <Link href="/home" className="flex flex-col items-center text-gray-600">
          <Home className="w-6 h-6" />
          <span className="text-xs">Home</span>
        </Link>
        <Link href="/attendance" className="flex flex-col items-center text-gray-600">
          <Calendar className="w-6 h-6" />
          <span className="text-xs">Attendance</span>
        </Link>
        <Link href="/promotion" className="flex flex-col items-center text-gray-600">
          <Heart className="w-6 h-6" />
          <span className="text-xs">Promotion</span>
        </Link>
        <Link href="/wallet" className="flex flex-col items-center text-gray-600">
          <Wallet className="w-6 h-6" />
          <span className="text-xs">Wallet</span>
        </Link>
        <Link href="/account" className="flex flex-col items-center text-red-600">
          <User className="w-6 h-6" />
          <span className="text-xs">Account</span>
        </Link>
      </div>
    </div>
  )
}

