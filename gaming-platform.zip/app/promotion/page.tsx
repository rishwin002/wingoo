'use client'

import { ClipboardCopy, Home, Calendar, Heart, Wallet, User } from 'lucide-react'
import Link from 'next/link'
import Image from 'next/image'
import { cn } from "@/lib/utils"
import { useState } from 'react'

export default function PromotionPage() {
  const [activeTab, setActiveTab] = useState('overview')

  const tabs = ['Overview', 'My Team', 'Tutorial', 'Guide']

  const handleCopyReferral = () => {
    navigator.clipboard.writeText('YOUR_REFERRAL_CODE')
  }

  const handleCopyLink = () => {
    navigator.clipboard.writeText('YOUR_REFERRAL_LINK')
  }

  return (
    <div className="min-h-screen bg-gray-50 flex flex-col">
      {/* Header */}
      <div className="bg-red-600 p-4 flex justify-between items-center">
        <h1 className="text-xl font-bold text-white flex items-center">
          PROMOTION AGENT
          <span className="ml-2">📋</span>
        </h1>
      </div>

      {/* Tab Navigation */}
      <div className="bg-white">
        <div className="flex border-b">
          {tabs.map((tab) => (
            <button
              key={tab}
              onClick={() => setActiveTab(tab.toLowerCase().replace(' ', ''))}
              className={cn(
                "flex-1 py-3 text-sm font-medium border-b-2 transition-colors",
                activeTab === tab.toLowerCase().replace(' ', '')
                  ? "border-red-600 text-red-600"
                  : "border-transparent text-gray-600"
              )}
            >
              {tab}
            </button>
          ))}
        </div>
      </div>

      {/* Overview Content */}
      {activeTab === 'overview' && (
        <div className="p-4 space-y-4">
          <div className="grid grid-cols-2 gap-4">
            {/* Team Members Stats */}
            <div className="border border-red-100 rounded-lg p-4">
              <div className="text-center">
                <div className="font-bold mb-1">Total Team Members</div>
                <div className="text-2xl text-red-600 font-bold mb-2">6</div>
                <div className="text-sm text-gray-600 text-left space-y-1">
                  <div>Team total recharge: 1000</div>
                  <div>Team Recharge commission: 10</div>
                </div>
              </div>
            </div>

            {/* Betting Stats */}
            <div className="border border-red-100 rounded-lg p-4">
              <div className="text-center">
                <div className="font-bold mb-1">Team total Betting:</div>
                <div className="text-2xl text-red-600 font-bold mb-2">20</div>
                <div className="text-sm text-gray-600 text-left">
                  <div>Team Betting Commission: 0.02</div>
                </div>
              </div>
            </div>
          </div>

          {/* QR Code Section */}
          <div className="flex flex-col items-center space-y-4">
            <div className="w-48 h-48 bg-white border rounded-lg overflow-hidden">
              <Image
                src="/placeholder.svg?height=192&width=192"
                alt="QR Code"
                width={192}
                height={192}
                className="w-full h-full"
              />
            </div>
            <p className="text-sm text-gray-500">Long press to save QR code</p>
            
            {/* Action Buttons */}
            <button
              onClick={handleCopyReferral}
              className="w-full bg-red-600 text-white py-3 rounded-lg font-medium flex items-center justify-center space-x-2"
            >
              <ClipboardCopy className="w-4 h-4" />
              <span>Copy Referral Code</span>
            </button>
            
            <button
              onClick={handleCopyLink}
              className="w-full bg-red-600 text-white py-3 rounded-lg font-medium flex items-center justify-center space-x-2"
            >
              <ClipboardCopy className="w-4 h-4" />
              <span>Copy Link</span>
            </button>
          </div>
        </div>
      )}

      {/* Bottom Navigation */}
      <div className="mt-auto fixed bottom-0 left-0 right-0 h-16 bg-white border-t flex items-center justify-around">
        <Link href="/home" className="flex flex-col items-center text-gray-600">
          <Home className="w-6 h-6" />
          <span className="text-xs">Home</span>
        </Link>
        <Link href="/attendance" className="flex flex-col items-center text-gray-600">
          <Calendar className="w-6 h-6" />
          <span className="text-xs">Attendance</span>
        </Link>
        <Link href="/promotion" className="flex flex-col items-center text-red-600">
          <Heart className="w-6 h-6" />
          <span className="text-xs">Promotion</span>
        </Link>
        <Link href="/wallet" className="flex flex-col items-center text-gray-600">
          <Wallet className="w-6 h-6" />
          <span className="text-xs">Wallet</span>
        </Link>
        <Link href="/account" className="flex flex-col items-center text-gray-600">
          <User className="w-6 h-6" />
          <span className="text-xs">Account</span>
        </Link>
      </div>

      {/* Bottom Padding for Navigation */}
      <div className="h-16" />
    </div>
  )
}

