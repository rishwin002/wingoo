'use client'

import { RefreshCw, Home, Calendar, Heart, Wallet, User } from 'lucide-react'
import Image from 'next/image'
import Link from 'next/link'

export default function AttendancePage() {
  const rewards = [
    { amount: 2, claimed: false },
    { amount: 4, claimed: false },
    { amount: 8, claimed: false },
    { amount: 16, claimed: false },
    { amount: 24, claimed: false },
    { amount: 28, claimed: false },
    { amount: 30, claimed: false },
  ]

  return (
    <div className="min-h-screen bg-white flex flex-col">
      {/* Header */}
      <div className="bg-gradient-to-b from-red-500 to-red-600 p-4 pb-20 relative overflow-hidden">
        <div className="flex justify-between items-center">
          <h1 className="text-xl font-bold text-white">LOCATION</h1>
          <button className="text-white">
            <RefreshCw className="w-6 h-6" />
          </button>
        </div>
        
        {/* Decorative Elements */}
        <div className="absolute inset-0 pointer-events-none">
          <div className="absolute top-1/2 right-4 w-8 h-8 bg-yellow-300/20 rounded-full" />
          <div className="absolute top-1/4 left-4 w-6 h-6 bg-pink-300/20 rounded-full" />
          <div className="absolute bottom-1/4 right-8 w-4 h-4 bg-green-300/20 rounded-full" />
        </div>
      </div>

      {/* Content */}
      <div className="px-4 -mt-16 relative z-10">
        <div className="text-center mb-6">
          <h2 className="text-white text-xl font-bold mb-4">Signed today</h2>
          <button className="bg-yellow-400 px-8 py-2 rounded-full text-sm font-medium shadow-lg">
            Rules of the game
          </button>
        </div>

        <div className="grid grid-cols-2 gap-4">
          {rewards.map((reward, index) => (
            <div
              key={index}
              className="bg-gradient-to-b from-red-500 to-red-600 rounded-2xl p-4 flex flex-col items-center"
            >
              <div className="mb-2">
                <Image
                  src="/placeholder.svg?height=40&width=40"
                  alt="Coin"
                  width={40}
                  height={40}
                  className="animate-bounce"
                />
              </div>
              <div className="text-xl font-bold text-white mb-3">
                {reward.amount}₹
              </div>
              <button className="w-full bg-white text-red-600 py-2 rounded-lg text-sm font-medium">
                Get it now
              </button>
            </div>
          ))}
        </div>
      </div>

      {/* Bottom Navigation */}
      <div className="mt-auto fixed bottom-0 left-0 right-0 h-16 bg-white border-t flex items-center justify-around">
        <Link href="/home" className="flex flex-col items-center text-gray-600">
          <Home className="w-6 h-6" />
          <span className="text-xs">Home</span>
        </Link>
        <Link href="/attendance" className="flex flex-col items-center text-red-600">
          <Calendar className="w-6 h-6" />
          <span className="text-xs">Attendance</span>
        </Link>
        <Link href="/promotion" className="flex flex-col items-center text-gray-600">
          <Heart className="w-6 h-6" />
          <span className="text-xs">Promotion</span>
        </Link>
        <Link href="/wallet" className="flex flex-col items-center text-gray-600">
          <Wallet className="w-6 h-6" />
          <span className="text-xs">Wallet</span>
        </Link>
        <Link href="/account" className="flex flex-col items-center text-gray-600">
          <User className="w-6 h-6" />
          <span className="text-xs">Account</span>
        </Link>
      </div>

      {/* Bottom Padding for Navigation */}
      <div className="h-16" />
    </div>
  )
}

