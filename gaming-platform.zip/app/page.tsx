'use client'

import { Bell, Download, Home, Calendar, Heart, Wallet, User, Volume2 } from 'lucide-react'
import Image from 'next/image'
import Link from 'next/link'
import { Button } from "@/components/ui/button"

export default function HomePage() {
  const games = [
    { id: 1, image: '/placeholder.svg?width=100&height=100', bg: 'bg-purple-500' },
    { id: 2, image: '/placeholder.svg?width=100&height=100', bg: 'bg-purple-500' },
    { id: 3, image: '/placeholder.svg?width=100&height=100', bg: 'bg-purple-500' },
    { id: 4, image: '/placeholder.svg?width=100&height=100', bg: 'bg-purple-500' },
  ]

  return (
    <div className="min-h-screen bg-white flex flex-col">
      {/* Header */}
      <header className="bg-red-600 px-4 py-2 flex justify-between items-center">
        <div className="flex items-center gap-2">
          <Image
            src="/placeholder.svg?width=32&height=32"
            alt="Logo"
            width={32}
            height={32}
            className="rounded-full"
          />
          <span className="text-white text-xl font-bold">DAMAN</span>
        </div>
        <Button variant="ghost" className="text-white p-2 h-auto">
          <Download className="w-5 h-5" />
        </Button>
      </header>

      {/* Banner */}
      <div className="relative w-full aspect-[2/1]">
        <Image
          src="/placeholder.svg?width=600&height=300"
          alt="Banner"
          fill
          className="object-cover"
        />
        <div className="absolute inset-0 flex flex-col items-center justify-center text-white">
          <h1 className="text-4xl font-bold mb-2">SIGN UP</h1>
          <p className="text-xl">SPIN & WIN</p>
        </div>
      </div>

      {/* Notification Bar */}
      <div className="px-4 py-2 flex items-center gap-2">
        <Volume2 className="w-5 h-5 text-red-600" />
        <p className="flex-1 text-sm truncate">
          Welcome to DAMAN - Play and win exciting prizes!
        </p>
        <Button className="bg-red-600 hover:bg-red-700 text-white text-xs h-7 px-3">
          Latest Notification
        </Button>
      </div>

      {/* Game Grid */}
      <div className="grid grid-cols-4 gap-4 px-4 my-4">
        {games.map((game) => (
          <div
            key={game.id}
            className={`aspect-square relative rounded-lg overflow-hidden ${game.bg}`}
          >
            <Image
              src={game.image}
              alt={`Game ${game.id}`}
              fill
              className="object-cover"
            />
          </div>
        ))}
      </div>

      {/* Win Go Section */}
      <div className="mx-4 p-4 bg-blue-400 rounded-lg text-white">
        <div className="flex items-center gap-2">
          <h2 className="text-xl font-bold">WIN GO</h2>
          <div className="ml-auto flex gap-1">
            <div className="w-6 h-6 rounded-full bg-green-500 flex items-center justify-center">0</div>
            <div className="w-6 h-6 rounded-full bg-green-500 flex items-center justify-center">↻</div>
            <div className="w-6 h-6 rounded-full bg-red-500 flex items-center justify-center">↩</div>
          </div>
        </div>
        <p className="text-sm my-2">Guess green/purple/red to win the game</p>
        <div className="flex justify-between items-center">
          <div className="flex items-center gap-2">
            <Image
              src="/placeholder.svg?width=24&height=24"
              alt="User"
              width={24}
              height={24}
              className="rounded-full"
            />
            <span className="text-sm">Member08...</span>
          </div>
          <span className="text-sm">Bet185</span>
        </div>
      </div>

      {/* Bottom Navigation */}
      <div className="mt-auto fixed bottom-0 left-0 right-0 h-16 bg-white border-t flex items-center justify-around">
        <Link href="/home" className="flex flex-col items-center text-red-600">
          <Home className="w-6 h-6" />
          <span className="text-xs">Home</span>
        </Link>
        <Link href="/attendance" className="flex flex-col items-center text-gray-600">
          <Calendar className="w-6 h-6" />
          <span className="text-xs">Attendance</span>
        </Link>
        <Link href="/promotion" className="flex flex-col items-center text-gray-600">
          <Heart className="w-6 h-6" />
          <span className="text-xs">Promotion</span>
        </Link>
        <Link href="/wallet" className="flex flex-col items-center text-gray-600">
          <Wallet className="w-6 h-6" />
          <span className="text-xs">Wallet</span>
        </Link>
        <Link href="/account" className="flex flex-col items-center text-gray-600">
          <User className="w-6 h-6" />
          <span className="text-xs">Account</span>
        </Link>
      </div>

      {/* Bottom Padding for Navigation */}
      <div className="h-16" />
    </div>
  )
}

