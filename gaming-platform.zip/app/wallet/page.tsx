'use client'

import { RefreshCw, Home, Calendar, Heart, Wallet, User, ChevronRight, CreditCard } from 'lucide-react'
import Link from 'next/link'
import Image from 'next/image'

export default function WalletPage() {
  return (
    <div className="min-h-screen bg-red-600 flex flex-col">
      {/* Header */}
      <div className="p-4 flex justify-between items-center">
        <h1 className="text-xl font-bold text-white">Wallet</h1>
        <button className="text-white">
          <RefreshCw className="w-6 h-6" />
        </button>
      </div>

      {/* Profile Section */}
      <div className="text-center text-white py-4">
        <Image
          src="/placeholder.svg?height=64&width=64"
          alt="Profile"
          width={64}
          height={64}
          className="mx-auto rounded-full mb-2"
        />
        <h2 className="text-xl font-bold">DIGIRG CLOUD</h2>
      </div>

      {/* Main Content */}
      <div className="flex-1 bg-white rounded-t-3xl p-4">
        <div className="mb-6">
          <h3 className="text-lg mb-4">Wallet</h3>
          
          {/* Balance Card */}
          <div className="bg-gradient-to-r from-yellow-400 to-orange-400 rounded-lg p-4 text-white mb-4">
            <div className="flex justify-between items-center mb-2">
              <span>My balance:</span>
              <RefreshCw className="w-4 h-4" />
            </div>
            <div className="text-3xl font-bold mb-4">51237400.00 ₹</div>
            <div className="flex justify-between text-sm">
              <div>
                <div>Total Recharge</div>
                <div>80800.00 ₹</div>
              </div>
              <div className="text-right">
                <div>Total Withdraw</div>
                <div>1000.00 ₹</div>
              </div>
            </div>
          </div>

          {/* Action Buttons */}
          <div className="grid grid-cols-2 gap-4">
            <button className="py-2 px-4 bg-yellow-400 rounded-full font-medium text-white shadow-lg">
              WITHDRAWAL
            </button>
            <button className="py-2 px-4 bg-red-500 rounded-full font-medium text-white shadow-lg">
              RECHARGE
            </button>
          </div>
        </div>

        {/* Deposit History */}
        <Link 
          href="/deposit-history"
          className="flex items-center justify-between p-4 border-t"
        >
          <div className="flex items-center gap-3">
            <CreditCard className="w-5 h-5 text-green-500" />
            <span>Deposit History</span>
          </div>
          <ChevronRight className="w-5 h-5 text-gray-400" />
        </Link>
      </div>

      {/* Bottom Navigation */}
      <div className="fixed bottom-0 left-0 right-0 h-16 bg-white border-t flex items-center justify-around">
        <Link href="/home" className="flex flex-col items-center text-gray-600">
          <Home className="w-6 h-6" />
          <span className="text-xs">Home</span>
        </Link>
        <Link href="/attendance" className="flex flex-col items-center text-gray-600">
          <Calendar className="w-6 h-6" />
          <span className="text-xs">Attendance</span>
        </Link>
        <Link href="/promotion" className="flex flex-col items-center text-gray-600">
          <Heart className="w-6 h-6" />
          <span className="text-xs">Promotion</span>
        </Link>
        <Link href="/wallet" className="flex flex-col items-center text-red-600">
          <Wallet className="w-6 h-6" />
          <span className="text-xs">Wallet</span>
        </Link>
        <Link href="/account" className="flex flex-col items-center text-gray-600">
          <User className="w-6 h-6" />
          <span className="text-xs">Account</span>
        </Link>
      </div>
    </div>
  )
}

